#include <iostream>
#include "playerCharacter.h"
#include "AutoDisplay.h"
#include "floor.h"
#include "drow.h"
#include "vampire.h"
#include "troll.h"
#include "goblin.h"
#include "shade.h"

bool freeze = false;

int main() {

    while (true) {
        AutoDisplay *ad = new AutoDisplay; // initializes an autodisplay
        Floor f; // initializes a floor

        ad->printOptions(); // Displays the screen for player to choose race
        char c;
        PlayerCharacter *pc = nullptr;
        while (true) {
            if (std::cin >> c) {
                if (c == 'd') {
                    pc = new Drow;
                    break;} else if (c == 'v') {
                    pc = new Vampire;
                    break;
                } else if (c == 'g') {
                    pc = new Goblin;
                    break;
                } else if (c == 't') {
                    pc = new Troll;
                    break;
                } else if (c == 's') {
                    pc = new Shade;
                    break;
                } else {
                    std::cout << "invalid selection";
                }
            } else { //if no input -- default shade
                pc = new Shade;
                break;
            }
        }

        f.init(*pc); // initializes the floor
        std::cout << f; // prints the floor to the display
        ad->printStats(*pc, f.getLevel()); // first page after floor is initialized last 5 lines after floor

        std::string command;

        while (true) {
            std::cin >> command;
            if (command == "u") {
                std::string dir;
                std::cin >> dir;
                f.usePotion(*pc, dir);
            } else if (command == "a") {
                std::string dir;
                std::cin >> dir;
                f.attackEnemy(*pc, dir);
            } else if (command == "f") {
                // is this an enhancement??
                if (freeze) freeze = false; 
                else freeze = true; 
            } else if (command == "r") {
                delete ad;
                delete pc;
                break;
            } else if (command == "q") {
                delete ad;
                delete pc;
                break;
            } else {
                f.movePC(*pc,command);
            }
            if (!freeze) {f.moveEnemies();}
        }

        if (command == "q") {
            break;
        }


    }

}
