#include "item.h"


Item::Item(int amt): amt{amt} {}

int Item::getAmt(){
    return amt;
}