#ifndef CC3K_FINAL_PROJECT_OBSERVER_H
#define CC3K_FINAL_PROJECT_OBSERVER_H

class Subject;
class Cell;

class Observer {
public:
    virtual void notify(Cell &whoNotified) = 0;
    virtual void notify(Subject &whoFrom){};
};

#endif //CC3K_FINAL_PROJECT_OBSERVER_H
