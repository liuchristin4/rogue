#include "cell.h"
#include "observer.h"
#include "subject.h"
#include "character.h"
#include "item.h"
#include "playerCharacter.h"

Cell::Cell(int row, int col, char type, bool occupied):
        row{row}, col{col}, type{type}, occupied{occupied} {}


// Gets notification from neighbour
void Cell::notify(Cell &whoFrom) {
    if (getType() != '.') { return; } // Do nothing is the cell is not a floor tile
    if (!whoFrom.isOccupied()) { return; } // Do nothing if the cell is not occupied

    // Case 1: the occupant is an enemy
    if (getOccupant() == "Enemy") {
        if (whoFrom.getOccupant() == "PlayerCharacter" ) {
            whoFrom.getCharacter()->struckBy(*character);
        }
    }

    // Case 2: the occupant is a PC
    else if (getOccupant() == "PlayerCharacter" ) {
        if (item == Items::SH || item == Items::NH || item == Items::MH) {
            //TODOO realItem->passEffect(*(dynamic_cast<PlayerCharacter*>(character)));
            item = Items::None;
            realItem = nullptr;
        }
    }

    // TODO: Implement dragon and dragon hoard
    // Case 3: the occupant is DragonHoard


}


void Cell::notifyObservers() {
    for (auto &o: observers){ o->notify(*this); }
}

// Get occupant
std::string Cell::getOccupant() {
    return occupant;
}

// checks if cell is occupied by anything
bool Cell::isOccupied() {
    return occupied;
}

// Updates status when character leaves the spot
void Cell::leaveOccupant() {
    character = nullptr;
    occupied = false;
}

// Returns pointer to either an PC or Enemy
Character * Cell::getCharacter() {
    return character;
}

// updates type of occupant in cell when Character moves onto it
void Cell::setCharacter(std::string occ, Character *c) {
    character = c;
    occupant = occ;
    occupied = true;
}

// Returns pointer to either Potion or Treasure
Item *Cell::getItem() { return realItem; }


// Returns the Items type from Items enum
Items Cell::getEnumItem() { return item; }

// sets item to point at i
void Cell::setItem(Item * i, Items it) {
    item = it;
    realItem = i;
    occupied = true;
}

// Returns the type of the cell
char Cell::getType() { return type; }

// returns which row cell is in
int Cell::getRow() { return row; }

// returns which col cell is in
int Cell::getCol() { return col; }

