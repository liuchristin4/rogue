#include "enemy.h"

Enemy::Enemy(int Hp, int Atk, int Def, std::string race):
        Character{Hp, Atk, Def, race}{}


