#include "floor.h"
#include <iostream>
#include <fstream>
#include <ctime>
#include <cstdlib>
#include <utility>
#include "normal.h"
#include "small.h"
#include "dragonhoard.h"

#include "BA.h"
#include "BD.h"
#include "WD.h"
#include "WA.h"
#include "PH.h"
#include "RH.h"
#include "dwarf.h"
#include "orc.h"
#include "halfling.h"
#include "human.h"
#include "merchant.h"
#include "elf.h"
#include "dragon.h"
#include "textdisplay.h"
#include "cell.h"
#include "item.h"
#include "enemy.h"
#include "coordinate.h"
#include "playerCharacter.h"//TODO ADDED THIS CHECK


//using namespace std;

std::istream &operator>>(std::istream &in, Floor &f){
  std::vector<Cell> row;
  char character;
  while (in >> character){
      for (unsigned int r = 0; r < f.maxRows; ++r){ //TODO substituted maxRows for 30 same as 79
        f.theFloor.emplace_back(row); // TODO: check why it's invalid
        for (unsigned int c = 0; c < f.maxCols; ++c){
          f.theFloor[r].emplace_back(r,c,character,false); //creates floor of cells ??
        }
      } 
  }
  return in;
}



//random spawn coord
int Floor::genRandCoord(int &r, int &c){
  //set seed
  srand(time(NULL));
  int chamber;
  //randomize chamber 
  do{
    chamber = rand() % 5;
    
    if (chamber == 0){ //r:3-6 | c:3-28 (top left)
      r = rand() % 6 + 3;
      c = rand() % 28 + 3;
    } else if (chamber == 1){ //r:2-12 | c:39-75 (top right)
      r = rand() % 12 + 3;
      if (r <= 4){
        c = rand() % 61 + 39;
      } else if (r == 5){
        c = rand() % 69 + 39;
      } else if (r == 6){
        c = rand() % 72 + 39;
      } else { //r:7-12
        c = rand() % 75 + 39;
      }
    } else if (chamber == 2){ //r:10-12 | c:38-49 (middle)
      r = rand() % 12 + 10;
      c = rand() % 49 + 38;
    } else if (chamber == 3){ // (bottom left)
      r = rand() % 21 + 15;
      c = rand() % 24 + 4;
    } else { // (bottom right)
      r = rand() % 21 + 16;
      if (r <= 18){
        c = rand() % 75 + 65;
      } else {
        c = rand() % 75 + 37;
      }
    }
    //p = std::make_pair(r,c);
    //Coordinate c = (r,c);
  } while (std::find(taken.begin(), taken.end(), std::make_pair(r,c)) != taken.end());
  taken.emplace_back(std::make_pair(r,c));
  return chamber;
}

// Spawns PC and returns and int representing the chamber
// PC is spawned in
int Floor::spawnPC(PlayerCharacter &pc){
  int r, c;
  int chamber = genRandCoord(r,c);
  //Note: cell set in main
  pc.setRow(r);
  pc.setCol(c);
  theFloor[r][c].setCharacter("PlayerCharacter", &pc);
  theFloor[r][c].isOccupied();
  theFloor[r][c].notifyObservers();
  return chamber;
}

// Spawns stairs, makes sure the stair is not in the same chamber
// as the PC
void Floor::spawnStairs(int PCchamber){
  int chamber;
  int r, c;
  do {
    chamber = genRandCoord(r,c);
  } while (chamber == PCchamber);
  //theFloor[r][c].setType('//'); // TODO: create method
  theFloor[r][c].notifyObservers();
}

// Spawns 10 Potions in Floor
void Floor::spawnPotions(){
  int r, c;
  Item *i = nullptr;
  Items item;
  for (int a = 0; a < 10; ++a){
    int chamber = genRandCoord(r,c);
    int ind = rand() % 5; //equal probability
    if (ind == 0){
      i = new RH;
      item = Items::RH;
    } else if (ind == 1){
      i = new BA;
      item = Items::BA;
    } else if (ind == 2){
      i = new BD;
      item = Items::BD;
    } else if (ind == 3){
      i = new PH;
      item = Items::PH;
    } else if (ind == 4){
      i = new WA;
      item = Items::WA;
    } else {
      i = new WD;
      item = Items::WD;
    }
    theFloor[r][c].setItem(i, item);
    theFloor[r][c].notifyObservers();
  }

}


// Spawns 10 treasures
void Floor::spawnTreasure(){
  int r = 0;
  int c = 0;
  Item *i = nullptr;
  Items item;
  for (int a = 0; a < 10; ++a){
    int ind = rand() % 8 + 1;
    int chamber = genRandCoord(r,c);
    if (ind <= 5){ //5/8 normal
      i = new Normal;
      item = Items::NH;
    } else if (ind == 6){ //1/8 dragon
      i = new DragonHoard;
      item = Items::DH;
    } else { //1/4 small
      i = new Small;
      item = Items::SH;
    }
    theFloor[r][c].setItem(i, item);
    theFloor[r][c].notifyObservers();
  }
}


// Spawns 20 enemies in Floor
void Floor::spawnEnemies(){
  int r, c;
  Enemy *e = nullptr;
  for (int i = 0; i < 20; ++i){
    int ind = rand() % 18 + 1;
    int chamber = genRandCoord(r,c);
    if (ind <= 5){ //5/18
      e = new Halfling;
    } else if (ind <= 8) { //3/18
      e = new Dwarf;
    } else if (ind <= 12) { //4/18
      e = new Human;
    } else if (ind <= 14) { //2/18
      e = new Elf;
    } else if (ind <= 16) { //2/18
      e = new Orc;
    } else { //2/18
      e = new Merchant;
    }
    enemiesPtrs.emplace_back(e);
    theFloor[r][c].setCharacter("Enemy", e);
    theFloor[r][c].isOccupied();
    theFloor[r][c].notifyObservers();
  }

}

// destructor
Floor::~Floor(){
  delete td;
}

void Floor::init(PlayerCharacter &pc){
  theFloor.clear(); //clears previous floor;

  //set up the floor using input file
  std::ifstream file {"floor.txt"};
  file >> *this; //input operator overload

  td = new TextDisplay; //init text display
  //set up neighbours
  for (auto &row:theFloor){ 
    for (auto &cell:row){
      int cellC = cell.getCol();
      int cellR = cell.getRow();

      if (cellR+1 < maxRows){
        cell.attach(&theFloor[cellR+1][cellC]);
      }
      if (cellR+1 < maxRows && cellC+1 < maxCols){
        cell.attach(&theFloor[cellR+1][cellC+1]);
      }
      if (cellC+1 < maxCols){
        cell.attach(&theFloor[cellR][cellC+1]);
      }
      if (cellR-1 >= 0 && cellC+1 < maxCols){
        cell.attach(&theFloor[cellR-1][cellC+1]);
      }
      if (cellR-1 >= 0){
        cell.attach(&theFloor[cellR-1][cellC]);
      }
      if (cellR-1 >= 0 && cellC-1 >= 0){
        cell.attach(&theFloor[cellR-1][cellC-1]);
      }
      if (cellC-1 >= 0){
        cell.attach(&theFloor[cellR][cellC-1]);
      } 
      if (cellR+1 < maxRows && cellC-1 >= 0){
        cell.attach(&theFloor[cellR+1][cellC-1]);
      } 
      cell.attach(td);
      td->buildFloor(cell);
    }
/*
  //set up chambers
  //NW chamber
  for (int r = 3; r < 7; ++r){ 
    for (int c = 3; c < 29; ++c) { 
      theChambers[0].emplace_back(a,b);
    }
  }

  //SW chamber
  for (int r = 15; r < 22; ++r){ 
    for (int c = 4; c < 29; ++c) {
      theChambers[0].emplace_back(a,b);
    }
  }
*/
  int ch = spawnPC(pc); //Spawns PC and returns chamber PC is spawned in
  spawnStairs(ch); // Checks Stairs is not in PC's chamber
  spawnPotions();
  spawnTreasure();
  spawnEnemies();
  }
}

// Returns the level Floor is on
int Floor::getLevel(){
  return level;
}

void Floor::nextLevel(PlayerCharacter &pc){
  pc.setAtk(pc.getAtk()-pc.getBuffAtk());
  pc.setBuffAtk(0);
  pc.setDef(pc.getDef()-pc.getBuffDef());
  pc.setBuffDef(0);
  init(pc);
  ++level;
  //call functions 
}

// PC chooses to attack Enemy
void Floor::attackEnemy(PlayerCharacter &pc, std::string d){
  int r = pc.getRow();
  int c = pc.getCol();
  Character *e = nullptr;
  if (d == "no") {
    e = theFloor[r-1][c].getCharacter();
  } else if (d == "ne"){
    e = theFloor[r-1][c-1].getCharacter();
  } else if (d == "ea"){
    e = theFloor[r+1][c].getCharacter();
  } else if (d == "se"){
    e = theFloor[r+1][c+1].getCharacter();
  } else if (d == "so"){
    e = theFloor[r][c+1].getCharacter();
  } else if (d == "sw"){
    e = theFloor[r-1][c+1].getCharacter();
  } else if (d == "we"){
    e = theFloor[r][c-1].getCharacter();
  } else { //NW
    e = theFloor[r-1][c-1].getCharacter();
  }
  if (e != nullptr) {
    e->struckBy(pc);
    theFloor[r][c].notifyObservers();
  }
}

bool Floor::validType(Cell &c){
  return (c.getType()=='.' || c.getType()=='+' ||
            c.getType()=='#' || c.getType()=='\\');
}

void Floor::movePC(PlayerCharacter &pc, std::string d){
  int r = pc.getRow();
  int c = pc.getCol();
  theFloor[r][c].leaveOccupant();
    if (d == "no"){
      if (!validType(theFloor[r-1][c])) { //also isOccupied?
        throw InvalidMove();
      } else { 
        if (theFloor[r-1][c].getType()=='\\'){
          nextLevel(pc);
        } else {
          theFloor[r - 1][c].setCharacter("PC", &pc);
          theFloor[r - 1][c].isOccupied();
          theFloor[r - 1][c].notifyObservers();
        }
      }
    } else if (d == "ne"){
      if (!validType(theFloor[r-1][c+1])) { //also isOccupied?
        throw InvalidMove();
      } else { 
        if (theFloor[r-1][c+1].getType()=='\\') {
          nextLevel(pc);
        } else {
          theFloor[r-1][c+1].setCharacter("PC", &pc);
          theFloor[r-1][c+1].isOccupied();
          theFloor[r-1][c+1].notifyObservers();
        }
      }
    } else if (d == "ea"){
      if (!validType(theFloor[r][c+1])) { //also isOccupied?
        throw InvalidMove();
      } else { 
        if (theFloor[r][c+1].getType()=='\\'){
          nextLevel(pc);
        } else {
          theFloor[r][c+1].setCharacter("PC", &pc);
          theFloor[r][c+1].isOccupied();
          theFloor[r][c+1].notifyObservers();
        }
      }
    } else if (d == "se"){
      if (!validType(theFloor[r+1][c+1])) { //also isOccupied?
        throw InvalidMove();
      } else { 
        if (theFloor[r+1][c+1].getType()=='\\'){
          nextLevel(pc);
        } else {
          theFloor[r+1][c+1].setCharacter("PC", &pc);
          theFloor[r+1][c+1].isOccupied();
          theFloor[r+1][c+1].notifyObservers();
        }
      }
    } else if (d == "so"){
      if (!validType(theFloor[r+1][c])) { //also isOccupied?
        throw InvalidMove();
      } else { 
        if (theFloor[r+1][c].getType()=='\\'){
          nextLevel(pc);
        } else {
          theFloor[r+1][c].setCharacter("PC", &pc);
          theFloor[r+1][c].isOccupied();
          theFloor[r+1][c].notifyObservers();
        }
      }
    } else if (d == "sw"){
      if (!validType(theFloor[r+1][c-1])) { //also isOccupied?
        throw InvalidMove();
      } else { 
        if (theFloor[r+1][c-1].getType()=='\\'){
          nextLevel(pc);
        } else {
          theFloor[r+1][c-1].setCharacter("PC", &pc);
          theFloor[r+1][c-1].isOccupied();
          theFloor[r+1][c-1].notifyObservers();
        }
      }
    } else if (d == "we"){
      if (!validType(theFloor[r][c-1])) { //also isOccupied?
        throw InvalidMove();
      } else {
        if (theFloor[r][c-1].getType()=='\\'){
          nextLevel(pc);
        } else {
          theFloor[r][c-1].setCharacter("PC", &pc);
          theFloor[r][c-1].isOccupied();
          theFloor[r][c-1].notifyObservers();
        }
      }
    } else { //NW
      if (!validType(theFloor[r-1][c-1])) { //also isOccupied?
        throw InvalidMove();
      } else { 
        if (theFloor[r-1][c-1].getType()=='\\'){
          nextLevel(pc);
        } else {
          theFloor[r-1][c-1].setCharacter("PC", &pc);
          theFloor[r-1][c-1].isOccupied();
          theFloor[r-1][c-1].notifyObservers();
        }
    }
    theFloor[r][c].notifyObservers();
    }

}

void Floor::usePotion(PlayerCharacter &pc, std::string d){
  int r = pc.getRow();
  int c = pc.getCol();
   if (d == "no"){
      theFloor[r-1][c].getItem()->passEffect(pc);
      theFloor[r-1][c].setItem(nullptr, Items::None);
      theFloor[r-1][c].notifyObservers();
    } else if (d == "ne"){
      theFloor[r+1][c-1].getItem()->passEffect(pc);
      theFloor[r+1][c-1].setItem(nullptr, Items::None);
      theFloor[r+1][c-1].notifyObservers();
    } else if (d == "ea"){
      theFloor[r+1][c].getItem()->passEffect(pc);
      theFloor[r+1][c].setItem(nullptr, Items::None);
      theFloor[r+1][c].notifyObservers();
    } else if (d == "se"){
      theFloor[r+1][c+1].getItem()->passEffect(pc);
      theFloor[r+1][c+1].setItem(nullptr, Items::None);
      theFloor[r+1][c+1].notifyObservers();
    } else if (d == "so"){
      theFloor[r][c+1].getItem()->passEffect(pc);
      theFloor[r][c+1].setItem(nullptr, Items::None);
      theFloor[r][c+1].notifyObservers();
    } else if (d == "sw"){
      theFloor[r-1][c+1].getItem()->passEffect(pc);
      theFloor[r-1][c+1].setItem(nullptr, Items::None);
      theFloor[r-1][c+1].notifyObservers();
    } else if (d == "we"){
      theFloor[r][c-1].getItem()->passEffect(pc);
      theFloor[r][c-1].setItem(nullptr, Items::None);
      theFloor[r][c-1].notifyObservers();
    } else { //NW
      theFloor[r-1][c-1].getItem()->passEffect(pc);
      theFloor[r-1][c-1].setItem(nullptr, Items::None);
      theFloor[r-1][c-1].notifyObservers();
    }
}

// Moves all the enemies on the floor to one of its
// adjacent floor tile cells
// 1 = North, 2 = NEast, 3 = East , 4 = SEast, 5 = South, 6 = SWest,
// 7 = West, 8 = NEast
void Floor::moveEnemies(){
    for (auto &e: enemiesPtrs) {
      int r = e->getRow();
      int c = e->getCol();
      while(true){ //we want to generate the dir until it is a valid one
        int dir = rand() % 8 + 1;

        if(dir == 1 && validType(theFloor[r-1][c])){ //if dir is NO
          theFloor[r-1][c].setCharacter("Enemy", e);
          theFloor[r-1][c].isOccupied();
          theFloor[r-1][c].notifyObservers();
          break;
        } else if(dir == 2 && validType(theFloor[r+1][c-1])){ //if dir is NE
          theFloor[r+1][c-1].setCharacter("Enemy", e);
          theFloor[r+1][c-1].isOccupied();
          theFloor[r+1][c-1].notifyObservers();
          break;
        } else if(dir == 3 && validType(theFloor[r][c+1])){ //if dir is east
          theFloor[r][c+1].setCharacter("Enemy", e);
          theFloor[r][c+1].isOccupied();
          theFloor[r][c+1].notifyObservers();
          break;
        } else if(dir == 4 && validType(theFloor[r+1][c+1])){ //if dir is SE
          theFloor[r+1][c+1].setCharacter("Enemy", e);
          theFloor[r+1][c+1].isOccupied();
          theFloor[r+1][c+1].notifyObservers();
          break;
        } else if(dir == 5 && validType(theFloor[r+1][c])){ //if dir is SO
          theFloor[r+1][c].setCharacter("Enemy", e);
          theFloor[r+1][c].isOccupied();
          theFloor[r+1][c].notifyObservers();
          break;
        } else if(dir == 6 && validType(theFloor[r+1][c-1])){ //if dir is SW
          theFloor[r+1][c-1].setCharacter("Enemy", e);
          theFloor[r+1][c-1].isOccupied();
          theFloor[r+1][c-1].notifyObservers();
          break;
        } else if(dir == 7 && validType(theFloor[r][c-1])){ //if dir is WE
          theFloor[r][c-1].setCharacter("Enemy", e);
          theFloor[r][c-1].isOccupied();
          theFloor[r][c-1].notifyObservers();
          break;
        } else {
            if(validType(theFloor[r-1][c-1])){ //if dir is NW
              theFloor[r-1][c-1].setCharacter("Enemy", e);
              theFloor[r-1][c-1].isOccupied();
              theFloor[r-1][c-1].notifyObservers();
              break;
            }
        }

      }
      theFloor[r][c].leaveOccupant();
      theFloor[r][c].notifyObservers();
    }
}

void Floor::dropGold(){

}

void Floor::getScore(PlayerCharacter &pc){
  pc.getGold();
}

std::ostream &operator<<(std::ostream &out, const Floor &f){
  out << *(f.td); // TODO: fix later
  return out;
}
