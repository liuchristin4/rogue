#ifndef _FLOOR_H_
#define _FLOOR_H_
#include <vector>
#include <algorithm>
#include <string>
#include "coordinate.h"
#include "cell.h"

class PlayerCharacter;
class Enemy;
//class Cell;
class Item;

//using namespace std;

class TextDisplay;
class InvalidMove{};

class Floor{
  const int maxRows = 30;
  const int maxCols = 79;
    std::vector<std::pair<int,int>> taken;
  /*
  vector<vector<Coordinate>> theChambers(5); //each chamber is a vector of coord
  vector<char> enemies(18) = {'H','H','H','H','D','D','D','A','A','A','A','A','E','E','O','O','O'};
  vector<string> potions(6) = {"RH","PH","BA","WA","BD","WD"};
  vector<char> treasures(8) = {'N','N','N','N','N','S','S','D'};
  */
  std::vector<Enemy *> enemiesPtrs; //TODO I erased the 20!!!!
  TextDisplay *td = nullptr;
  int level;
  int goldScore;
  bool validType(Cell &c);
  int genRandCoord(int &r, int &c);

  public:
  ~Floor();
  void init(PlayerCharacter &pc);
  void attackEnemy(PlayerCharacter &pc, std::string d);
  int getLevel();
  void nextLevel(PlayerCharacter &pc);
  void getScore(PlayerCharacter &pc);
  void movePC(PlayerCharacter &pc, std::string d);
  void usePotion(PlayerCharacter &pc, std::string d);
  void moveEnemies();
  int spawnPC(PlayerCharacter &pc);
  void spawnStairs(int PCchamber);
  void spawnPotions();
  void spawnTreasure();
  void spawnEnemies();
  void dropGold();

  friend std::istream &operator>>(std::istream &in, Floor &f);
  friend std::ostream &operator<<(std::ostream &out, const Floor &f);

    std::vector<std::vector<Cell>> theFloor;
};

#endif
