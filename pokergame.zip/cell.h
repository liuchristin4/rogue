#ifndef _CELL_H_
#define _CELL_H_

#include <string>
#include "subject.h"
#include "observer.h"

class Character;
class Item;

class PlayerCharacter;

enum class Items { RH, BA, BD, PH, WA, WD, NH, SH, MH, DH, None};

class Cell: public Subject, public Observer{
    const int row, col;
    const char type;
    bool occupied;
    Character *character;
    Items item = Items::None;
    Item * realItem;
    std::string occupant; 

public:
    Cell(int row, int col, char type, bool occupied);
    void notifyObservers() override;
    void notify(Cell &whoFrom) override;
    std::string getOccupant();
    bool isOccupied();
    void leaveOccupant();
    Character *getCharacter();
    void setCharacter(std::string occ, Character *c);
    Item *getItem();
    Items getEnumItem();
    void setItem(Item *i, Items it);
    char getType(); // get the type (i.e. #, |, -, ., ...etc.)
    int getRow();
    int getCol();

};

#endif
